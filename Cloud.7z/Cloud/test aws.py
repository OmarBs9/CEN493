import boto3

s3 = boto3.client('s3')
s3.upload_file('/home/omar/Desktop/python/Face-Rec/dataset/Mohammed/Mohammed_1.jpg','gp2-s3','qq.jpg')